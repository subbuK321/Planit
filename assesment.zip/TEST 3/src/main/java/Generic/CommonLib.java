package Generic;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

public class CommonLib {
	WebDriver driver;
	public CommonLib(WebDriver driver){
		this.driver=driver;
	}
	public static ExtentTest testinfo;
	    public void Scroll (WebDriver driver ,int startpixel,int endpixel){
				RemoteWebDriver r = (RemoteWebDriver) driver;
				String j= "window.scrollTo("+Integer.toString(startpixel)+","+Integer.toString(endpixel)+")";

				r.executeScript(j);
		}



}
